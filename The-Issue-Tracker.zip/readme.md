
# The Issue Tracker
Simple  app for storing the project and its issues using html,css,js and node.js

## Table of Contents
* Generalinfo
* Technology
* Setup
* Functionality
* status

## Introduction    
    This project serves as an Ultimate query tools for all developers 
    , it serves storing the project information and issues related to it including its author, title, description and labels.
    The main incentive for this project is to master Node.js,
    a part of my online course in coding ninjas.

## Technology
    1. Bootstrap 5.2v
    2. html
    3. css
    4. Vanilla javascript
    5. Node.js

## Setup
    The app has all the required files and libraries in it in the form of links.
    $ npm start to start app in terminal in visual studio code
    Open localhost:3000 in your browser.
    We will have our application home page.

## Functionality
    * Showing Project list.
    * Storing Project infomation.
    * Showing Project issues by clicking view.
    * Able to add issue on current project.
    * Able to filter project on basis of two or more labels or auhtor or title and description.

## Status
    This project is completely developed and has functionality, however
    some improvements can be made, some are the users should be allowed to 
    search via category of the content and the search box suggestions can be 
    improved